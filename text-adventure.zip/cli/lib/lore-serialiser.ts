// tag CLI — Lore Serialiser
// Pure functions for .lore.md generation and parsing.

import type {
  GmState, NpcMutation, Quest, CodexMutation, TimeState,
  MapState, StoryArchitectState, CarryForward, ArcSummary,
} from '../types';
import { SCHEMA_VERSION } from './constants';

// ── Types ────────────────────────────────────────────────────────────

export type PreviousAdventurer = {
  name: string;
  class: string;
  level: number;
} | null;

export type LoreMechanicalData = {
  _loreVersion: 1;
  _schemaVersion: string;
  rosterMutations: NpcMutation[];
  factions: Record<string, number>;
  quests: Quest[];
  worldFlags: Record<string, boolean | number | string>;
  time: TimeState;
  modulesActive: string[];
  seed?: string;
  theme?: string;
  visualStyle?: string;
  codexMutations: CodexMutation[];
  mapState?: MapState;
  storyArchitect?: StoryArchitectState;
  arc?: number;
  arcType?: 'standard' | 'epic' | 'branching';
  carryForward?: CarryForward | null;
  arcHistory?: ArcSummary[];
  previousAdventurer: PreviousAdventurer;
};

// ── Faction label thresholds ─────────────────────────────────────────

function factionLabel(standing: number): string {
  if (standing < -50) return 'hostile';
  if (standing < -20) return 'unfriendly';
  if (standing <= 20) return 'neutral';
  if (standing <= 50) return 'friendly';
  return 'allied';
}

// ── extractMechanicalData ────────────────────────────────────────────

export function extractMechanicalData(state: GmState): LoreMechanicalData {
  const previousAdventurer: PreviousAdventurer = state.character
    ? { name: state.character.name, class: state.character.class, level: state.character.level }
    : null;

  // Reset codex states to locked
  const codexMutations: CodexMutation[] = state.codexMutations.map(c => ({
    ...c,
    state: 'locked' as const,
  }));

  // Empty visitedZones in mapState
  const mapState: MapState | undefined = state.mapState
    ? { ...state.mapState, visitedZones: [] }
    : undefined;

  const data: LoreMechanicalData = {
    _loreVersion: 1,
    _schemaVersion: SCHEMA_VERSION,
    rosterMutations: state.rosterMutations,
    factions: state.factions,
    quests: state.quests,
    worldFlags: state.worldFlags,
    time: state.time,
    modulesActive: state.modulesActive,
    seed: state.seed,
    theme: state.theme,
    visualStyle: state.visualStyle,
    codexMutations,
    mapState,
    storyArchitect: state.storyArchitect,
    arc: state.arc,
    arcType: state.arcType,
    carryForward: state.carryForward,
    arcHistory: state.arcHistory,
    previousAdventurer,
  };

  return data;
}

// ── encodeLorePayload ────────────────────────────────────────────────

export function encodeLorePayload(data: LoreMechanicalData): string {
  return 'LF1:' + btoa(JSON.stringify(data));
}

// ── extractLorePayload ───────────────────────────────────────────────

const RE_LORE_PAYLOAD = /<!--\s*LORE:([\da-fA-F]{8}\.LF\d+:[\S]+)\s*-->/;

export function extractLorePayload(content: string): string | null {
  const match = content.match(RE_LORE_PAYLOAD);
  return match ? match[1]! : null;
}

// ── extractFrontmatterField ──────────────────────────────────────────

export function extractFrontmatterField(content: string, field: string): string | null {
  const fmMatch = content.match(/^---\n([\s\S]*?)\n---/);
  if (!fmMatch) return null;
  const frontmatter = fmMatch[1]!;
  // Escape special regex characters in field name
  const escaped = field.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const lineMatch = frontmatter.match(new RegExp(`^${escaped}:\\s*(.+)$`, 'm'));
  if (!lineMatch) return null;
  let value = lineMatch[1]!.trim();
  // Strip surrounding quotes
  if ((value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))) {
    value = value.slice(1, -1);
  }
  return value;
}

// ── buildLoreMarkdown ────────────────────────────────────────────────

function buildFrontmatter(state: GmState): string {
  const now = new Date().toISOString();
  const title = state.theme
    ? `Lore Export — ${state.theme}`
    : 'Lore Export';
  const calendarSystem = state.time?.calendarSystem ?? 'elapsed-only';
  const startDate = state.time?.date ?? 'Day 1';
  const startTime = state.time?.hour != null ? `${state.time.hour}:00` : '08:00';
  const modules = state.modulesActive ?? [];

  const lines = [
    '---',
    'format: text-adventure-lore',
    'version: 1',
    `skill-version: ${SCHEMA_VERSION}`,
    `title: "${title}"`,
    'author: GM',
    `theme: ${state.theme ?? 'unset'}`,
    'tone: unset',
    'acts: 3',
    'estimated-scenes: 30',
    'players: 1',
    'difficulty: normal',
    'edited: false',
    'exported: true',
    `exported-from: scene ${state.scene}`,
    `exported-date: ${now}`,
    `seed: ${state.seed ?? 'none'}`,
    `calendar-system: ${calendarSystem}`,
    `start-date: ${startDate}`,
    `start-time: ${startTime}`,
    `recommended-styles: ${state.visualStyle ?? 'default'}`,
    `required-modules: ${modules.join(', ') || 'none'}`,
    `optional-modules: none`,
    '---',
  ];
  return lines.join('\n');
}

function buildPreviousAdventurer(state: GmState): string {
  const lines = ['## Previous Adventurer', ''];
  if (state.character) {
    lines.push(`**${state.character.name}** — ${state.character.class}, Level ${state.character.level}`);
  } else {
    lines.push('No previous adventurer.');
  }
  lines.push('');
  return lines.join('\n');
}

function buildLocationAtlas(state: GmState): string {
  const lines = ['## Location Atlas', ''];
  if (state.mapState) {
    lines.push(`- **Current Zone:** ${state.mapState.currentZone}`);
    if (state.mapState.revealedZones.length > 0) {
      lines.push(`- **Revealed Zones:** ${state.mapState.revealedZones.join(', ')}`);
    }
    for (const [door, doorState] of Object.entries(state.mapState.doorStates)) {
      lines.push(`- **Door** ${door}: ${doorState}`);
    }
  } else {
    lines.push('No map data available.');
  }
  lines.push('');
  return lines.join('\n');
}

function buildNpcRoster(state: GmState): string {
  const lines = ['## NPC Roster', ''];
  if (state.rosterMutations.length === 0) {
    lines.push('No NPCs registered.');
    lines.push('');
    return lines.join('\n');
  }
  for (const npc of state.rosterMutations) {
    lines.push(`### ${npc.name}`);
    lines.push('');
    lines.push(`- **ID:** ${npc.id}`);
    lines.push(`- **Role:** ${npc.role}`);
    lines.push(`- **Pronouns:** ${npc.pronouns}`);
    lines.push(`- **Tier:** ${npc.tier}`);
    lines.push(`- **Level:** ${npc.level}`);
    lines.push(`- **HP:** ${npc.hp}/${npc.maxHp}`);
    lines.push(`- **AC:** ${npc.ac}`);
    lines.push(`- **Soak:** ${npc.soak}`);
    lines.push(`- **Damage Dice:** ${npc.damageDice}`);
    lines.push(`- **Disposition:** ${npc.disposition} (trust: ${npc.trust})`);
    lines.push(`- **Status:** ${npc.status}`);
    const stats = Object.entries(npc.stats).map(([k, v]) => `${k}: ${v}`).join(', ');
    lines.push(`- **Stats:** ${stats}`);
    const mods = Object.entries(npc.modifiers).map(([k, v]) => `${k}: ${v}`).join(', ');
    lines.push(`- **Modifiers:** ${mods}`);
    lines.push('');
    lines.push('*Prose description: (to be written by GM)*');
    lines.push('');
  }
  return lines.join('\n');
}

function buildStorySpine(state: GmState): string {
  const lines = ['## Story Spine', ''];
  if (state.quests.length === 0) {
    lines.push('No quests registered.');
    lines.push('');
    return lines.join('\n');
  }
  for (const quest of state.quests) {
    lines.push(`### ${quest.title}`);
    lines.push('');
    lines.push(`- **ID:** ${quest.id}`);
    lines.push(`- **Status:** ${quest.status}`);
    if (quest.objectives.length > 0) {
      lines.push('- **Objectives:**');
      for (const obj of quest.objectives) {
        const check = obj.completed ? '[x]' : '[ ]';
        lines.push(`  - ${check} ${obj.description}`);
      }
    }
    if (quest.clues.length > 0) {
      lines.push(`- **Clues:** ${quest.clues.join('; ')}`);
    }
    lines.push('');
  }
  return lines.join('\n');
}

function buildFactionDynamics(state: GmState): string {
  const lines = ['## Faction Dynamics', ''];
  const entries = Object.entries(state.factions);
  if (entries.length === 0) {
    lines.push('No factions registered.');
    lines.push('');
    return lines.join('\n');
  }
  for (const [name, standing] of entries) {
    const label = factionLabel(standing);
    lines.push(`- **${name}:** ${standing} (${label})`);
  }
  lines.push('');
  return lines.join('\n');
}

function buildCodexEntries(state: GmState): string {
  const lines = ['## Codex Entries', ''];
  if (state.codexMutations.length === 0) {
    lines.push('No codex entries.');
    lines.push('');
    return lines.join('\n');
  }
  for (const entry of state.codexMutations) {
    lines.push(`- **${entry.id}:** ${entry.state}`);
    if (entry.via) lines.push(`  - Discovered via: ${entry.via}`);
  }
  lines.push('');
  return lines.join('\n');
}

export function buildLoreMarkdown(state: GmState): string {
  const sections = [
    buildFrontmatter(state),
    '',
    '## World History',
    '',
    '*(World history to be written by GM based on the adventure so far.)*',
    '',
    buildPreviousAdventurer(state),
    buildLocationAtlas(state),
    buildNpcRoster(state),
    buildStorySpine(state),
    '## Encounter Tables',
    '',
    '*(Encounter tables to be designed by GM.)*',
    '',
    '## Loot and Rewards',
    '',
    '*(Loot tables to be designed by GM.)*',
    '',
    buildFactionDynamics(state),
    buildCodexEntries(state),
  ];
  return sections.join('\n');
}

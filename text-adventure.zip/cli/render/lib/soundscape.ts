// SoundscapeEngine — Web Audio API atmosphere generator.
// Extracted from scene.ts for testability and SRP.
// Generates inline JS that defines the SoundscapeEngine prototype.

export const SOUNDSCAPE_ENGINE_CODE: string = `
    var SoundscapeEngine = function() {
      this.ctx = null; this.nodes = []; this.playing = false; this.timeout = null;
    };
    SoundscapeEngine.prototype.init = function() {
      if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    };
    SoundscapeEngine.prototype.play = function(type, duration) {
      this.stop(); this.init();
      duration = Math.min(duration || 25, 30);
      var generators = {
        'ship-engine': function(e) { e.genDrone(45, 0.15, duration); e.genNoise('lowpass', 150, 0.08, duration); },
        'rain': function(e) { e.genNoise('bandpass', 1000, 0.15, duration); },
        'wind': function(e) { e.genNoise('bandpass', 400, 0.12, duration); },
        'forest': function(e) { e.genNoise('bandpass', 2000, 0.08, duration); },
        'mechanical': function(e) { e.genDrone(80, 0.09, duration); },
        'terminal': function(e) { e.genNoise('highpass', 3000, 0.08, duration); },
        'alarm': function(e) { e.genAlarm(440, 880, 0.2, duration); },
        'silence': function(e) { e.genNoise('lowpass', 100, 0.02, duration); },
      };
      var gen = generators[type] || generators['silence'];
      gen(this);
      this.playing = true;
      var self = this;
      this.timeout = setTimeout(function() { self.stop(); }, duration * 1000);
    };
    SoundscapeEngine.prototype.stop = function() {
      this.nodes.forEach(function(n) { try { n.stop(); } catch(e) {} try { n.disconnect(); } catch(e) {} });
      this.nodes = []; this.playing = false;
      if (this.timeout) { clearTimeout(this.timeout); this.timeout = null; }
      if (this.ctx) { try { this.ctx.close(); } catch(e) {} this.ctx = null; }
      var btn = document.getElementById('audio-btn');
      if (btn) btn.textContent = '\\u266b Play';
    };
    SoundscapeEngine.prototype.genDrone = function(freq, vol, dur) {
      var osc = this.ctx.createOscillator(); var gain = this.ctx.createGain();
      var lfo = this.ctx.createOscillator(); var lfoGain = this.ctx.createGain();
      osc.type = 'sine'; osc.frequency.value = freq;
      lfo.type = 'sine'; lfo.frequency.value = 0.2; lfoGain.gain.value = 3;
      lfo.connect(lfoGain); lfoGain.connect(osc.frequency);
      osc.connect(gain); gain.gain.value = vol; gain.connect(this.ctx.destination);
      gain.gain.setValueAtTime(0, this.ctx.currentTime);
      gain.gain.linearRampToValueAtTime(vol, this.ctx.currentTime + 2);
      gain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + dur);
      osc.start(); lfo.start(); this.nodes.push(osc, lfo);
    };
    SoundscapeEngine.prototype.genNoise = function(filterType, freq, vol, dur) {
      var bufSize = this.ctx.sampleRate * dur;
      var buffer = this.ctx.createBuffer(1, bufSize, this.ctx.sampleRate);
      var data = buffer.getChannelData(0);
      for (var i = 0; i < bufSize; i++) data[i] = Math.random() * 2 - 1;
      var source = this.ctx.createBufferSource(); source.buffer = buffer;
      var filter = this.ctx.createBiquadFilter(); filter.type = filterType; filter.frequency.value = freq;
      var gain = this.ctx.createGain(); gain.gain.value = vol;
      gain.gain.setValueAtTime(0, this.ctx.currentTime);
      gain.gain.linearRampToValueAtTime(vol, this.ctx.currentTime + 1);
      gain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + dur);
      source.connect(filter); filter.connect(gain); gain.connect(this.ctx.destination);
      source.start(); this.nodes.push(source);
    };
    SoundscapeEngine.prototype.genAlarm = function(f1, f2, vol, dur) {
      var osc = this.ctx.createOscillator(); var gain = this.ctx.createGain();
      osc.type = 'square'; gain.gain.value = vol;
      osc.connect(gain); gain.connect(this.ctx.destination);
      for (var i = 0; i < Math.floor(dur); i++) osc.frequency.setValueAtTime(i % 2 === 0 ? f1 : f2, this.ctx.currentTime + i);
      gain.gain.setValueAtTime(vol, this.ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + dur);
      osc.start(); this.nodes.push(osc);
    };`.trim();
